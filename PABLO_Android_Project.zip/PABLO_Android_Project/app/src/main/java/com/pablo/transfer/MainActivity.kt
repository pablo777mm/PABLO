package com.pablo.transfer

import android.content.Context
import android.net.wifi.WifiManager
import android.os.Bundle
import android.provider.OpenableColumns
import android.net.Uri
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.net.ServerSocket
import java.net.Socket
import java.net.InetAddress
import java.net.NetworkInterface
import java.util.Collections

private val Bg = Color(0xFF080808)
private val Panel = Color(0xFF171717)
private val Red = Color(0xFFE53935)
private val White = Color(0xFFF5F5F5)
private val Muted = Color(0xFFAAAAAA)
private const val PORT = 8988

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PabloApp() }
    }
}

@Composable
fun PabloApp() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var selectedUri by remember { mutableStateOf<Uri?>(null) }
    var selectedName by remember { mutableStateOf("ماكو ملف محدد") }
    var targetIp by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("جاهز للاتصال") }
    var serverRunning by remember { mutableStateOf(false) }
    var network by remember { mutableStateOf(readNetworkInfo(context)) }

    val picker = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            selectedUri = uri
            selectedName = queryName(context, uri) ?: "ملف محدد"
            try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        }
    }

    Surface(modifier = Modifier.fillMaxSize(), color = Bg) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                    Column {
                        Text("PABLO", color = White, fontSize = 29.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
                        Text("نقل الملفات المباشر", color = Red, fontSize = 13.sp)
                    }
                    Surface(color = Panel, shape = RoundedCornerShape(50)) {
                        Text("الإصدار 1.0", color = Muted, modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 11.sp)
                    }
                }
            }
            item {
                Image(
                    painter = painterResource(id = R.drawable.pablo_header),
                    contentDescription = "صورة واجهة بابلو",
                    modifier = Modifier.fillMaxWidth().height(190.dp)
                )
            }
            item { SectionTitle("نقل الملفات") }
            item {
                Column(modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("الملف المحدد", color = Muted, fontSize = 12.sp)
                    Text(selectedName, color = White, fontWeight = FontWeight.SemiBold)
                    Button(
                        onClick = { picker.launch(arrayOf("*/*")) },
                        colors = ButtonDefaults.buttonColors(containerColor = Red),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.FolderOpen, null)
                        Spacer(Modifier.width(8.dp))
                        Text("تصفح الملفات واختيار ملف")
                    }
                    OutlinedTextField(
                        value = targetIp,
                        onValueChange = { targetIp = it },
                        label = { Text("عنوان IP للجهاز المستلم") },
                        placeholder = { Text("مثال: 192.168.1.105") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = White, unfocusedTextColor = White,
                            focusedBorderColor = Red, unfocusedBorderColor = Muted,
                            focusedLabelColor = Red, unfocusedLabelColor = Muted,
                            cursorColor = Red
                        )
                    )
                    Button(
                        onClick = {
                            val uri = selectedUri
                            if (uri == null || targetIp.isBlank()) {
                                status = "اختار ملف واكتب عنوان IP أولاً"
                            } else {
                                scope.launch {
                                    status = "جاري الإرسال..."
                                    status = sendFile(context, uri, targetIp.trim())
                                }
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Red),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Send, null)
                        Spacer(Modifier.width(8.dp))
                        Text("إرسال الملف")
                    }
                    OutlinedButton(
                        onClick = {
                            if (!serverRunning) {
                                serverRunning = true
                                status = "جاري تشغيل الاستقبال على المنفذ $PORT"
                                scope.launch {
                                    status = receiveFile(context)
                                    serverRunning = false
                                }
                            } else {
                                status = "الاستقبال يعمل حالياً"
                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = White)
                    ) {
                        Icon(Icons.Default.Download, null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (serverRunning) "الاستقبال يعمل" else "بدء استقبال الملفات")
                    }
                }
            }
            item { SectionTitle("معلومات الشبكة") }
            item {
                Column(modifier = Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    InfoRow("عنوان IP", network.ip)
                    InfoRow("البوابة الافتراضية", network.gateway)
                    InfoRow("قناع الشبكة", network.mask)
                    InfoRow("DNS", network.dns)
                    InfoRow("المنفذ", PORT.toString())
                    OutlinedButton(onClick = { network = readNetworkInfo(context) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Refresh, null)
                        Spacer(Modifier.width(6.dp))
                        Text("تحديث معلومات الشبكة")
                    }
                }
            }
            item {
                Text(status, color = if (status.contains("نجح")) Color(0xFF75D69C) else Muted, fontSize = 13.sp)
                Text("ملاحظة: يجب أن يكون الجهازان على نفس شبكة Wi‑Fi. هذا إصدار أولي ويحتاج اختباراً عملياً على جهازين.", color = Muted, fontSize = 11.sp)
            }
        }
    }
}

@Composable
fun SectionTitle(title: String) {
    Text(title, color = White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Muted, fontSize = 13.sp)
        Text(value, color = White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

data class NetInfo(val ip: String, val gateway: String, val mask: String, val dns: String)

fun readNetworkInfo(context: Context): NetInfo {
    return try {
        val wifi = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        @Suppress("DEPRECATION")
        val dhcp = wifi.dhcpInfo
        fun ip(n: Int): String = if (n == 0) "غير متاح" else listOf(0, 8, 16, 24).joinToString(".") { ((n shr it) and 0xff).toString() }
        val localIp = try {
            Collections.list(NetworkInterface.getNetworkInterfaces()).flatMap { Collections.list(it.inetAddresses) }
                .firstOrNull { !it.isLoopbackAddress && it is java.net.Inet4Address }?.hostAddress ?: "غير متاح"
        } catch (_: Exception) { ip(dhcp.ipAddress) }
        NetInfo(localIp, ip(dhcp.gateway), ip(dhcp.netmask), "${ip(dhcp.dns1)} / ${ip(dhcp.dns2)}")
    } catch (_: Exception) {
        NetInfo("غير متاح", "غير متاح", "غير متاح", "غير متاح")
    }
}

fun queryName(context: Context, uri: Uri): String? {
    return context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
        if (it.moveToFirst()) it.getString(0) else null
    }
}

suspend fun sendFile(context: Context, uri: Uri, host: String): String = withContext(Dispatchers.IO) {
    try {
        val name = queryName(context, uri) ?: "file.bin"
        Socket().use { socket ->
            socket.connect(InetAddress.getByName(host).let { java.net.InetSocketAddress(it, PORT) }, 10000)
            val size = context.contentResolver.openAssetFileDescriptor(uri, "r")?.length ?: -1L
            DataOutputStream(socket.getOutputStream()).use { out ->
                out.writeUTF(name)
                out.writeLong(size)
                context.contentResolver.openInputStream(uri)?.use { input ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        out.write(buffer, 0, count)
                    }
                } ?: throw IllegalStateException("تعذر فتح الملف")
                out.flush()
            }
        }
        "تم إرسال الملف بنجاح"
    } catch (e: Exception) {
        "فشل الإرسال: ${e.localizedMessage ?: "تحقق من IP والاتصال"}"
    }
}

suspend fun receiveFile(context: Context): String = withContext(Dispatchers.IO) {
    try {
        val folder = java.io.File(context.getExternalFilesDir(null), "PABLO_Received")
        folder.mkdirs()
        ServerSocket(PORT).use { server ->
            server.soTimeout = 120000
            server.accept().use { socket ->
                DataInputStream(BufferedInputStream(socket.getInputStream())).use { input ->
                    val name = java.io.File(input.readUTF()).name
                    val size = input.readLong()
                    val outputFile = java.io.File(folder, name)
                    outputFile.outputStream().use { output ->
                        val buffer = ByteArray(64 * 1024)
                        var remaining = size
                        if (size >= 0) {
                            while (remaining > 0) {
                                val count = input.read(buffer, 0, minOf(buffer.size.toLong(), remaining).toInt())
                                if (count < 0) break
                                output.write(buffer, 0, count)
                                remaining -= count
                            }
                        } else {
                            while (true) {
                                val count = input.read(buffer)
                                if (count < 0) break
                                output.write(buffer, 0, count)
                            }
                        }
                    }
                }
            }
        }
        "نجح الاستقبال. حُفظ الملف داخل مجلد PABLO_Received"
    } catch (e: Exception) {
        "تعذر الاستقبال: ${e.localizedMessage ?: "حدث خطأ"}"
    }
}
